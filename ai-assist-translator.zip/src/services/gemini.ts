import { GoogleGenAI, GenerateContentResponse } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });

export interface TranslationResult {
  originalText: string;
  translatedText: string;
  detectedLanguage: string;
}

export async function translateAudio(base64Audio: string, mimeType: string): Promise<TranslationResult> {
  const model = "gemini-3-flash-preview";
  
  const prompt = `
    Analyze the provided audio. 
    1. Transcribe the spoken words exactly as they are in the original language.
    2. Detect the language of the speech.
    3. Translate the transcribed text into clear, professional English.
    
    Return the result in JSON format with the following keys:
    - originalText: The transcription in the original language.
    - translatedText: The English translation.
    - detectedLanguage: The name of the detected language (e.g., "Spanish", "French", "Japanese").
  `;

  try {
    const response: GenerateContentResponse = await ai.models.generateContent({
      model,
      contents: [
        {
          parts: [
            { text: prompt },
            {
              inlineData: {
                mimeType,
                data: base64Audio,
              },
            },
          ],
        },
      ],
      config: {
        responseMimeType: "application/json",
      },
    });

    const text = response.text;
    if (!text) throw new Error("No response from AI");
    
    return JSON.parse(text) as TranslationResult;
  } catch (error) {
    console.error("Gemini Translation Error:", error);
    throw error;
  }
}
